"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from logslice.parser import Record

FORMAT_VERSION = 1

# Keep CACHE_DIR for backward compatibility with tests
# It's used as a fallback when no environment variables are set
CACHE_DIR = Path.home() / ".cache" / "logslice"


def _get_cache_dir() -> Path:
    """Get the cache directory according to XDG spec.
    
    Resolved at runtime (not import time) in this order:
    1. $LOGSLICE_CACHE_DIR if set and non-empty, used as-is (no logslice subdirectory appended)
    2. $XDG_CACHE_HOME/logslice if XDG_CACHE_HOME is set and non-empty
    3. ~/.cache/logslice
    
    A ``directory=` argument to load()/store() always wins over these defaults.
    """
    if cache_dir := os.environ.get("LOGSLICE_CACHE_DIR", ""):
        if cache_dir:
            return Path(cache_dir)
    if cache_home := os.environ.get("XDG_CACHE_HOME", ""):
        if cache_home:
            return Path(cache_home) / "logslice"
    # Fallback to CACHE_DIR constant for backward compatibility
    return CACHE_DIR


def cache_key(path: Path) -> str:
    """Compute the cache key for a path.
    
    The key is based on the resolved path, size, and modification time.
    This allows the cache to be invalidated when the file is modified or when
    its size changes.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def _get_default_cache_dir() -> Path:
    """Get the default cache directory."""
    return _get_cache_dir()


def load(path: str | Path, directory: str | Path | None = None, ttl: int = 3600) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.
    
    Entries older than ``ttl`` seconds (default 3600) are treated as misses
    and the file is re-parsed.
    """
    if directory is None:
        directory = _get_default_cache_dir()
    else:
        directory = Path(directory)
    
    entry_path = _entry_path(Path(path), directory)
    try:
        data = json.loads(entry_path.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    
    # Check cache expiry
    if data.get("created_at", 0) is not None:
        age = time.time() - data["created_at"]
        if age >= ttl:
            # Cache expired, treat as miss and re-parse
            return None
    
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    if directory is None:
        directory = _get_default_cache_dir()
    else:
        directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
