import json
from pathlib import Path

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_cache_expiry(tmp_path):
    """Test that cache entries expire after the configured TTL."""
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    
    # Get the created_at time from the entry
    data = json.loads(entry.read_text())
    created_at = data["created_at"]
    
    # Wait for the cache to expire (use a short TTL for testing)
    import time
    time.sleep(2)  # Wait 2 seconds
    
    # Load with a short TTL (1 second) to force expiry
    assert cache.load(log, directory=tmp_path / "cache", ttl=1) is None


def test_cache_with_custom_directory(tmp_path):
    """Test that custom cache directory is used."""
    log = make_log(tmp_path)
    records = parse_file(log)
    custom_dir = tmp_path / "custom_cache"
    entry = cache.store(log, records, directory=custom_dir)
    assert entry.parent == custom_dir
    assert cache.load(log, directory=custom_dir) == records


def test_cache_with_custom_directory_via_env(tmp_path):
    """Test that LOGSLICE_CACHE_DIR environment variable is used."""
    import os
    env_dir = tmp_path / "env_cache"
    os.environ["LOGSLICE_CACHE_DIR"] = str(env_dir)
    
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records)  # No directory specified, should use env var
    assert entry.parent == env_dir
    
    # Clean up
    del os.environ["LOGSLICE_CACHE_DIR"]


def test_cache_key_is_public_no_underscore(tmp_path):
    """Test that cache_key function is public (no leading underscore)."""
    log_path = tmp_path / "test.log"
    log_path.write_text("test log")
    key = cache.cache_key(log_path)
    assert key is not None
    # Just verify it's a valid hex string (64 chars for SHA256)
    assert len(key) == 64
    assert key.isalnum()
