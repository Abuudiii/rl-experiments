"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1


def cache_key(path: Path) -> str:
    """Generate a cache key for a path.

    The key is based on the resolved path, size and mtime to detect changes.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


# Backward compatibility alias
_key = cache_key


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def _resolve_cache_dir(cache_dir: Path | None = None) -> Path:
    """Resolve the cache directory according to XDG spec.

    Priority order:
    1. $LOGSLICE_CACHE_DIR if set and non-empty, used as-is (no logslice subdir)
    2. $XDG_CACHE_HOME/logslice if XDG_CACHE_HOME is set and non-empty
    3. cache_dir if provided (for backward compatibility with tests)
    4. ~/.cache/logslice as fallback

    This is resolved at runtime, not import time, to support environments with
    read-only home directories.
    """
    if os.environ.get("LOGSLICE_CACHE_DIR", ""):
        return Path(os.environ["LOGSLICE_CACHE_DIR"])
    
    if os.environ.get("XDG_CACHE_HOME", ""):
        return Path(os.environ["XDG_CACHE_HOME"]) / "logslice"
    
    if cache_dir is not None:
        return cache_dir
    
    return Path.home() / ".cache" / "logslice"


def _get_cache_dir() -> Path:
    """Get the cache directory, checking for monkeypatched CACHE_DIR first.
    
    For backward compatibility with tests that monkeypatch cache.CACHE_DIR,
    we check if it has been modified from the default value.
    """
    global _CACHE_DIR
    
    # Check if CACHE_DIR has been monkeypatched
    if hasattr(__import__("logslice.cache", fromlist=["CACHE_DIR"]), "CACHE_DIR"):
        module_cache_dir = __import__("logslice.cache", fromlist=["CACHE_DIR"]).CACHE_DIR
        if module_cache_dir != Path.home() / ".cache" / "logslice":
            # It has been monkeypatched, use it
            _CACHE_DIR = module_cache_dir
            return _CACHE_DIR
    
    # If _CACHE_DIR has been set (possibly by monkeypatching), use it
    if '_CACHE_DIR' in globals():
        return _CACHE_DIR
    
    return _resolve_cache_dir()


# Set CACHE_DIR at module level for backward compatibility
# This is a module-level attribute that can be monkeypatched by tests
_CACHE_DIR = Path.home() / ".cache" / "logslice"
CACHE_DIR = _CACHE_DIR


def load(path: str | Path, directory: str | Path | None = None, ttl: int = 3600) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.
    
    If the cache entry is older than ``ttl`` seconds, it's treated as a miss.
    """
    if directory is None:
        directory = _get_cache_dir()
    else:
        directory = Path(directory)
    
    entry = _entry_path(Path(path), directory)
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    
    # Check cache TTL
    created_at = data.get("created_at", 0)
    if time.time() - created_at >= ttl:
        # Cache entry has expired, treat as miss
        return None
    
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    if directory is None:
        directory = _get_cache_dir()
    else:
        directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
