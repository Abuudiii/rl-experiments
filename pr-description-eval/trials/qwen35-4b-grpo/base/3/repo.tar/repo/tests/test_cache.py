import json
import time

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache._key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache._key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_cache_ttl_short(tmp_path):
    """Test that cache entries expire after a short TTL."""
    log = make_log(tmp_path)
    records = parse_file(log)
    
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    
    # Store with a short TTL of 1 second
    cache.store(log, records, directory=cache_dir)
    
    # Verify cache works immediately
    loaded = cache.load(log, directory=cache_dir, ttl=1)
    assert loaded == records
    
    # Wait for cache to expire (1 second + small buffer)
    time.sleep(1.1)
    
    # Cache should be a miss now
    loaded = cache.load(log, directory=cache_dir, ttl=1)
    assert loaded is None


def test_cache_reloads_on_expiry(tmp_path):
    """Test that cache entries are re-parsed when they expire."""
    log = make_log(tmp_path)
    records_before = parse_file(log)
    
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    
    # Store with a short TTL
    cache.store(log, records_before, directory=cache_dir)
    
    # Cache should work
    loaded = cache.load(log, directory=cache_dir, ttl=1)
    assert loaded == records_before
    
    # Wait for cache to expire
    time.sleep(1.1)
    
    # Cache should expire and return None (miss)
    loaded = cache.load(log, directory=cache_dir, ttl=1)
    assert loaded is None
    
    # After expiry, re-parsing should happen
    # The cache.load returns None on miss, and the caller should re-parse
    # Let's verify the file is still valid
    assert log.exists()


def test_cache_key_public_name(tmp_path):
    """Test that cache_key is publicly named."""
    log = make_log(tmp_path)
    # cache_key should exist and be callable
    assert callable(cache.cache_key)
    key = cache.cache_key(log)
    assert isinstance(key, str)
    assert len(key) == 64  # SHA256 hex length
