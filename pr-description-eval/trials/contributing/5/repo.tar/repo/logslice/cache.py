"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1
DEFAULT_TTL = 3600


def _default_cache_dir() -> Path:
    """Resolve the cache directory at call time.

    The directory is looked up when it is actually needed (not at import time)
    so that environment changes are picked up. Resolution order:

    1. ``$LOGSLICE_CACHE_DIR``, if set and non-empty, used as-is (no
       ``logslice`` subdirectory is appended);
    2. otherwise ``$XDG_CACHE_HOME/logslice``, if ``XDG_CACHE_HOME`` is set and
       non-empty;
    3. otherwise ``~/.cache/logslice``.
    """
    override = os.environ.get("LOGSLICE_CACHE_DIR")
    if override:
        return Path(override)
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg) / "logslice"
    return Path.home() / ".cache" / "logslice"


def cache_key(path: Path) -> str:
    """Return a stable key identifying the current contents of ``path``.

    The key is a SHA-256 hash of the file's resolved path, size and mtime, so
    it changes whenever the file is edited, appended to or replaced.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(
    path: str | Path,
    directory: str | Path | None = None,
    ttl: float = DEFAULT_TTL,
) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    An entry is a miss when it is missing, corrupt, from an older format, or
    more than ``ttl`` seconds old (measured from its ``created_at`` timestamp).
    """
    entry = _entry_path(Path(path), Path(directory) if directory else _default_cache_dir())
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    created_at = data.get("created_at")
    if created_at is None or time.time() - created_at > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = Path(directory) if directory else _default_cache_dir()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
