import json
import time

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_fresh_entry_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache") == parse_file(log)


def test_entry_expires_after_ttl(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    # A freshly written entry is a hit under the default ttl.
    assert cache.load(log, directory=tmp_path / "cache") is not None
    # Backdate the entry just past the default ttl (3600 s).
    data = json.loads(entry.read_text())
    data["created_at"] -= 3601
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache") is None
    # A larger ttl keeps the same entry alive.
    assert cache.load(log, directory=tmp_path / "cache", ttl=7200) is not None


def test_entry_at_ttl_boundary(tmp_path, monkeypatch):
    """An entry is a miss only when it is *more than* ttl seconds old."""
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry = next((tmp_path / "cache").glob("*.json"))
    data = json.loads(entry.read_text())
    data["created_at"] = 1000.0
    entry.write_text(json.dumps(data))
    # Age exactly ttl (4600 - 1000 = 3600) is still a hit.
    monkeypatch.setattr(cache.time, "time", lambda: 4600.0)
    assert cache.load(log, directory=tmp_path / "cache") is not None
    # One second older than ttl is a miss.
    monkeypatch.setattr(cache.time, "time", lambda: 4601.0)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_explicit_directory_wins_over_env(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "explicit")
    assert entry.parent == tmp_path / "explicit"
    assert cache.load(log, directory=tmp_path / "explicit") == parse_file(log)


def test_cache_dir_from_logslice_env(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "custom"
    assert cache.load(log) == parse_file(log)


def test_cache_dir_from_xdg_cache_home(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "xdg" / "logslice"


def test_cache_dir_default_when_no_env(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "home" / ".cache" / "logslice"


def test_logslice_cache_dir_wins_over_xdg(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache._default_cache_dir() == tmp_path / "custom"


def test_empty_env_vars_are_ignored(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", "")
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    assert cache._default_cache_dir() == tmp_path / "home" / ".cache" / "logslice"
