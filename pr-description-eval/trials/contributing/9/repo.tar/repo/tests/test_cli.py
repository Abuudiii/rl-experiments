import json

import pytest

from logslice import cache
from logslice.cli import main
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:01Z DEBUG [db] query took 3ms
2024-05-01T12:00:02Z WARN [http] slow response /search 1200ms
this line is not a log record
2024-05-01T13:15:00Z ERROR [db] connection reset by peer
2024-05-02T08:00:00Z INFO [auth] user alice logged in
"""


@pytest.fixture
def log_file(tmp_path):
    path = tmp_path / "app.log"
    path.write_text(SAMPLE)
    return path


def test_prints_matching_records(log_file, capsys):
    assert main([str(log_file), "--level", "error"]) == 0
    assert capsys.readouterr().out == "2024-05-01T13:15:00Z ERROR [db] connection reset by peer\n"


def test_json_output(log_file, capsys):
    main([str(log_file), "-c", "auth", "--json"])
    rows = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert rows == [
        {
            "timestamp": "2024-05-02T08:00:00Z",
            "level": "INFO",
            "component": "auth",
            "message": "user alice logged in",
            "line_no": 6,
        }
    ]


def test_count_by_component(log_file, capsys):
    main([str(log_file), "--count-by", "component"])
    assert capsys.readouterr().out == "db    2\nhttp  2\nauth  1\n"


def test_count_by_json(log_file, capsys):
    main([str(log_file), "--count-by", "level", "--json"])
    assert json.loads(capsys.readouterr().out) == {"INFO": 2, "DEBUG": 1, "ERROR": 1, "WARNING": 1}


def test_missing_file_exit_code(tmp_path, capsys):
    assert main([str(tmp_path / "nope.log")]) == 2
    assert "nope.log" in capsys.readouterr().err


def test_cache_flag_reuses_parsed_records(log_file, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "cache"))
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    first = capsys.readouterr().out
    assert len(list((tmp_path / "cache").glob("*.json"))) == 1

    def fail(path):
        raise AssertionError("parse_file should not be called on a cache hit")

    monkeypatch.setattr("logslice.cli.parse_file", fail)
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    assert capsys.readouterr().out == first


def test_no_cache_without_flag(log_file, tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "cache"))
    main([str(log_file)])
    assert not (tmp_path / "cache").exists()


def test_cache_ttl_expiry_reparses(log_file, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "cache"))
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    first = capsys.readouterr().out
    entry = next((tmp_path / "cache").glob("*.json"))

    # Backdate the cached entry beyond the TTL.
    data = json.loads(entry.read_text())
    data["created_at"] -= 7200
    entry.write_text(json.dumps(data))

    calls = []
    real_parse_file = parse_file

    def spy(path):
        calls.append(path)
        return real_parse_file(path)

    monkeypatch.setattr("logslice.cli.parse_file", spy)
    # With a 3600s TTL the backdated entry must be treated as a miss and re-parsed.
    assert main([str(log_file), "--cache", "--cache-ttl", "3600", "--count-by", "level"]) == 0
    assert capsys.readouterr().out == first
    assert calls == [str(log_file)]
    # The entry was refreshed with a new created_at.
    refreshed = json.loads(entry.read_text())
    assert refreshed["created_at"] > data["created_at"] + 7000


def test_cache_ttl_hit_does_not_reparse(log_file, tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "cache"))
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    first = capsys.readouterr().out

    def fail(path):
        raise AssertionError("parse_file should not be called on a cache hit")

    monkeypatch.setattr("logslice.cli.parse_file", fail)
    assert main([str(log_file), "--cache", "--cache-ttl", "3600", "--count-by", "level"]) == 0
    assert capsys.readouterr().out == first
