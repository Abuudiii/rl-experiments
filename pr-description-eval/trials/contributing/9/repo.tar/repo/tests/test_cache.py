import json

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_cache_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_fresh_entry_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) == parse_file(log)


def test_expired_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    # Backdate the entry by more than the TTL.
    data = json.loads(entry.read_text())
    data["created_at"] -= 7200
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None


def test_entry_within_ttl_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    # Backdate the entry by less than the TTL.
    data = json.loads(entry.read_text())
    data["created_at"] -= 10
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) == parse_file(log)


def test_entry_exactly_at_ttl_boundary_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    # Backdate the entry by exactly the TTL + a hair, so it is strictly older.
    data = json.loads(entry.read_text())
    data["created_at"] -= 3600.001
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None


def test_default_cache_dir_env_var(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    assert cache.default_cache_dir() == tmp_path / "custom"


def test_default_cache_dir_env_var_used_as_is(tmp_path, monkeypatch):
    # No "logslice" subdirectory is appended to LOGSLICE_CACHE_DIR.
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "custom"
    assert cache.load(log) == parse_file(log)


def test_default_cache_dir_xdg(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache.default_cache_dir() == tmp_path / "xdg" / "logslice"


def test_default_cache_dir_fallback(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    monkeypatch.setattr(cache.Path, "home", classmethod(lambda cls: tmp_path / "home"))
    assert cache.default_cache_dir() == tmp_path / "home" / ".cache" / "logslice"


def test_empty_env_vars_are_ignored(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache.default_cache_dir() == tmp_path / "xdg" / "logslice"


def test_explicit_directory_wins_over_env(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "explicit")
    assert entry.parent == tmp_path / "explicit"
