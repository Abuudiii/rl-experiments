"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1
DEFAULT_TTL = 3600


def default_cache_dir() -> Path:
    """Resolve the cache directory to use, lazily (not at import time).

    The directory is chosen in this order:

    1. ``$LOGSLICE_CACHE_DIR``, if set and non-empty, used as-is (no
       ``logslice`` subdirectory is appended);
    2. otherwise ``$XDG_CACHE_HOME/logslice``, if ``XDG_CACHE_HOME`` is set and
       non-empty;
    3. otherwise ``~/.cache/logslice``.
    """
    env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_dir:
        return Path(env_dir)
    xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache_home:
        return Path(xdg_cache_home) / "logslice"
    return Path.home() / ".cache" / "logslice"


def cache_key(path: Path) -> str:
    """Return a stable cache key for ``path``.

    The key is a hash of the file's resolved path, its size and its
    modification time, so any change to the file's contents or identity
    produces a different key.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(
    path: str | Path,
    directory: str | Path | None = None,
    ttl: float = DEFAULT_TTL,
) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    A miss occurs when there is no entry, the entry is corrupt or the wrong
    format version, or the entry is older than ``ttl`` seconds (measured from
    its ``created_at`` timestamp). ``ttl`` defaults to :data:`DEFAULT_TTL`.
    """
    entry = _entry_path(Path(path), Path(directory) if directory else default_cache_dir())
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    created_at = data.get("created_at")
    if created_at is not None and (time.time() - created_at) > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = Path(directory) if directory else default_cache_dir()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
