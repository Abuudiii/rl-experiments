import json
import time
from pathlib import Path

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_cache_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_expired_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    data["created_at"] = time.time() - 7200
    entry.write_text(json.dumps(data))
    # Older than the default TTL of 3600 s.
    assert cache.load(log, directory=tmp_path / "cache") is None
    # A larger TTL still serves the entry.
    assert cache.load(log, directory=tmp_path / "cache", ttl=10000) == parse_file(log)


def test_fresh_entry_is_not_expired(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    cache.store(log, records, directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) == records


def test_default_cache_dir_from_env(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    assert cache.default_cache_dir() == tmp_path / "custom"


def test_default_cache_dir_from_xdg(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache.default_cache_dir() == tmp_path / "xdg" / "logslice"


def test_default_cache_dir_fallback(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    assert cache.default_cache_dir() == Path.home() / ".cache" / "logslice"


def test_empty_env_vars_are_ignored(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", "")
    assert cache.default_cache_dir() == Path.home() / ".cache" / "logslice"


def test_store_load_use_default_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "envcache"))
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    log = make_log(tmp_path)
    records = parse_file(log)
    cache.store(log, records)
    assert (tmp_path / "envcache").is_dir()
    assert cache.load(log) == records
    # An explicit directory= argument wins over the environment.
    assert cache.load(log, directory=tmp_path / "elsewhere") is None
