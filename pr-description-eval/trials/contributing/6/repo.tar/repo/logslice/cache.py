"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1
DEFAULT_TTL = 3600


def _resolve_directory(directory: str | Path | None) -> Path:
    """Work out which directory holds the cache entries.

    An explicit ``directory`` always wins. Otherwise, in order:
    ``$LOGSLICE_CACHE_DIR`` (used as-is), ``$XDG_CACHE_HOME/logslice``, and
    finally ``~/.cache/logslice``.
    """
    if directory:
        return Path(directory)
    env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_dir:
        return Path(env_dir)
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg) / "logslice"
    return Path.home() / ".cache" / "logslice"


def cache_key(path: Path) -> str:
    """Return the cache key for ``path``.

    The key is a SHA-256 over the file's resolved path, size and mtime, so it
    changes whenever the file is edited, appended to or replaced in place.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(
    path: str | Path,
    directory: str | Path | None = None,
    ttl: float = DEFAULT_TTL,
) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    An entry is a miss if it is missing or unreadable, comes from an older
    format version, or was created more than ``ttl`` seconds ago.
    """
    entry = _entry_path(Path(path), _resolve_directory(directory))
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    if time.time() - data.get("created_at", 0.0) > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = _resolve_directory(directory)
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
