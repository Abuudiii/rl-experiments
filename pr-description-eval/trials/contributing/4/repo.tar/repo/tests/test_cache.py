import json
import time
from pathlib import Path

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def age_entry(entry, seconds):
    """Rewrite a cache entry so its ``created_at`` is ``seconds`` in the past."""
    data = json.loads(entry.read_text())
    data["created_at"] = time.time() - seconds
    entry.write_text(json.dumps(data))


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_fresh_entry_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    cache.store(log, records, directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) == records


def test_expired_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    age_entry(entry, 3601)
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None


def test_ttl_is_respected(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    # 1000s old: a miss under a 600s ttl, a hit under a 2000s ttl.
    age_entry(entry, 1000)
    assert cache.load(log, directory=tmp_path / "cache", ttl=600) is None
    assert cache.load(log, directory=tmp_path / "cache", ttl=2000) == records


def test_default_ttl_is_an_hour():
    assert cache.DEFAULT_TTL == 3600


def test_cache_dir_resolution(tmp_path, monkeypatch):
    # 1. LOGSLICE_CACHE_DIR wins and is used as-is.
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "override"))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache.cache_dir() == tmp_path / "override"

    # 2. Otherwise XDG_CACHE_HOME/logslice.
    monkeypatch.delenv("LOGSLICE_CACHE_DIR")
    assert cache.cache_dir() == tmp_path / "xdg" / "logslice"

    # 3. Otherwise ~/.cache/logslice.
    monkeypatch.delenv("XDG_CACHE_HOME")
    assert cache.cache_dir() == Path.home() / ".cache" / "logslice"


def test_empty_env_vars_are_ignored(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache.cache_dir() == tmp_path / "xdg" / "logslice"


def test_explicit_directory_wins_over_env(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "override"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") is not None
