import json
import time

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_cache_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def _age_entry(entry, seconds):
    data = json.loads(entry.read_text())
    data["created_at"] = time.time() - seconds
    entry.write_text(json.dumps(data))


def test_fresh_entry_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    _age_entry(entry, 10)  # well within the default TTL
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_expired_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    _age_entry(entry, 7200)  # older than the default TTL of 3600
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_ttl_is_configurable(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    _age_entry(entry, 7200)
    # A longer TTL still serves the entry...
    assert cache.load(log, directory=tmp_path / "cache", ttl=7201) == records
    # ...while a shorter one does not.
    assert cache.load(log, directory=tmp_path / "cache", ttl=10) is None


def test_entry_without_created_at_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    del data["created_at"]
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_directory_from_logslice_env(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "envcache"))
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "envcache"
    assert cache.load(log) == parse_file(log)


def test_directory_from_xdg_env(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "xdg" / "logslice"


def test_logslice_env_beats_xdg(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "envcache"))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "envcache"


def test_explicit_directory_wins_over_env(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "envcache"))
    entry = cache.store(log, parse_file(log), directory=tmp_path / "explicit")
    assert entry.parent == tmp_path / "explicit"


def test_empty_env_dir_falls_through(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "xdg" / "logslice"


def test_default_directory_is_home_cache(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    monkeypatch.setattr(cache.Path, "home", classmethod(lambda cls: tmp_path / "home"))
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "home" / ".cache" / "logslice"
