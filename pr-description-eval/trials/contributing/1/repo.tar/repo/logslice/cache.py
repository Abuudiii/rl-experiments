"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1
DEFAULT_TTL = 3600


def default_cache_dir() -> Path:
    """Return the directory cache entries are stored under.

    The directory is resolved lazily (when called, not at import time) so that
    the environment may change between import and use. Resolution order:

    1. ``$LOGSLICE_CACHE_DIR``, if set and non-empty, used as-is.
    2. otherwise ``$XDG_CACHE_HOME/logslice``, if ``XDG_CACHE_HOME`` is set and
       non-empty.
    3. otherwise ``~/.cache/logslice``.
    """
    env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_dir:
        return Path(env_dir)
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg) / "logslice"
    return Path.home() / ".cache" / "logslice"


def cache_key(path: Path) -> str:
    """Return the cache key for ``path``.

    The key is a hash of the file's resolved path, size and modification time,
    so editing, appending to, or moving the file produces a different key.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def _resolve_directory(directory: str | Path | None) -> Path:
    return Path(directory) if directory else default_cache_dir()


def load(
    path: str | Path,
    directory: str | Path | None = None,
    ttl: float = DEFAULT_TTL,
) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    A miss occurs when there is no entry, the entry is corrupt or has the
    wrong format version, or the entry's ``created_at`` is more than ``ttl``
    seconds in the past. The key changes whenever the file is modified, so a
    stale entry for a changed file is simply never looked up again.
    """
    entry = _entry_path(Path(path), _resolve_directory(directory))
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    if time.time() - data.get("created_at", 0) > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = _resolve_directory(directory)
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
