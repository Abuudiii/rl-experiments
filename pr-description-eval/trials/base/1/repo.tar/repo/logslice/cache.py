"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

DEFAULT_TTL = 3600
FORMAT_VERSION = 1


def cache_key(path: str | Path) -> str:
    """Return the cache key for ``path``.

    The key is a hash of the file's resolved path, size and modification
    time, so any change to the file's contents, size, or location yields a
    different key.
    """
    path = Path(path)
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def _default_directory() -> Path:
    """Resolve the cache directory from the environment.

    Resolution happens at call time so the environment can change between
    calls. ``$LOGSLICE_CACHE_DIR`` is used as-is when set and non-empty;
    otherwise ``$XDG_CACHE_HOME/logslice`` when ``XDG_CACHE_HOME`` is set
    and non-empty; otherwise ``~/.cache/logslice``.
    """
    override = os.environ.get("LOGSLICE_CACHE_DIR")
    if override:
        return Path(override)
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg) / "logslice"
    return Path.home() / ".cache" / "logslice"


def load(
    path: str | Path,
    directory: str | Path | None = None,
    *,
    ttl: float = DEFAULT_TTL,
) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    An entry is a miss when it is missing, corrupt, or when its ``created_at``
    timestamp is more than ``ttl`` seconds old.
    """
    entry = _entry_path(Path(path), Path(directory) if directory else _default_directory())
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    created_at = data.get("created_at")
    if not isinstance(created_at, (int, float)) or time.time() - created_at > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = Path(directory) if directory else _default_directory()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
