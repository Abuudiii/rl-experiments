import json
from pathlib import Path

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_directory_from_logslice_cache_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log))
    # LOGSLICE_CACHE_DIR wins and is used as-is: no "logslice" subdirectory.
    assert entry.parent == tmp_path / "custom"
    assert not (tmp_path / "xdg").exists()
    assert cache.load(log) == parse_file(log)


def test_directory_from_xdg_cache_home(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log))
    assert entry.parent == tmp_path / "xdg" / "logslice"


def test_default_directory_when_no_env(monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    assert cache._resolve_directory(None) == Path.home() / ".cache" / "logslice"


def test_empty_env_vars_fall_back(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", "")
    assert cache._resolve_directory(None) == Path.home() / ".cache" / "logslice"


def test_explicit_directory_wins_over_env(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "custom"))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "explicit")
    assert entry.parent == tmp_path / "explicit"
    assert not (tmp_path / "custom").exists()


def test_fresh_entry_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    cache.store(log, records, directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) == records


def test_expired_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    data["created_at"] -= 7200
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None
    # The same entry is still fresh under a longer TTL.
    assert cache.load(log, directory=tmp_path / "cache", ttl=7201) == records


def test_entry_without_created_at_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    del data["created_at"]
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache") is None
