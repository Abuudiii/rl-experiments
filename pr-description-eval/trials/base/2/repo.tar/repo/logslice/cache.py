"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1
DEFAULT_TTL = 3600


def default_cache_dir() -> Path:
    """Return the directory cache entries are stored in.

    Resolved lazily (at call time, not import time) so that environment
    changes are picked up. The directory is chosen in this order:

    1. ``$LOGSLICE_CACHE_DIR`` when set and non-empty, used as-is (no
       ``logslice`` subdirectory is appended);
    2. otherwise ``$XDG_CACHE_HOME/logslice`` when ``XDG_CACHE_HOME`` is set
       and non-empty;
    3. otherwise ``~/.cache/logslice``.
    """
    override = os.environ.get("LOGSLICE_CACHE_DIR")
    if override:
        return Path(override)
    xdg = os.environ.get("XDG_CACHE_HOME")
    if xdg:
        return Path(xdg) / "logslice"
    return Path.home() / ".cache" / "logslice"


def cache_key(path: Path) -> str:
    """Return a stable key identifying the current contents of ``path``.

    The key is a SHA-256 hash of the file's resolved path, size and
    modification time, so editing, appending or rewriting the file (with a
    different size or mtime) produces a different key.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: float = DEFAULT_TTL) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    A miss occurs when there is no entry, the entry is corrupt, its version
    does not match, or it is older than ``ttl`` seconds (measured from the
    entry's ``created_at`` timestamp). An explicit ``directory`` wins over
    the default cache directory.
    """
    entry = _entry_path(Path(path), Path(directory) if directory else default_cache_dir())
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    if time.time() - data.get("created_at", 0) > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = Path(directory) if directory else default_cache_dir()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
