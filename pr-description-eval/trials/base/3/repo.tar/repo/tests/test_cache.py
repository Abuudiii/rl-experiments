import json
import os
import time

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_cache_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_fresh_entry_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    cache.store(log, records, directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) == records


def test_entry_older_than_ttl_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry = next((tmp_path / "cache").glob("*.json"))
    data = json.loads(entry.read_text())
    data["created_at"] = time.time() - 3601
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None


def test_custom_ttl_is_respected(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    cache.store(log, records, directory=tmp_path / "cache")
    entry = next((tmp_path / "cache").glob("*.json"))
    data = json.loads(entry.read_text())
    data["created_at"] = time.time() - 20
    entry.write_text(json.dumps(data))
    # Within a 60-second TTL the entry is still fresh...
    assert cache.load(log, directory=tmp_path / "cache", ttl=60) == records
    # ...but expired under a 10-second TTL.
    assert cache.load(log, directory=tmp_path / "cache", ttl=10) is None


def test_default_ttl_is_one_hour():
    assert cache.DEFAULT_TTL == 3600
    import inspect
    assert inspect.signature(cache.load).parameters["ttl"].default == 3600


def test_default_cache_dir_prefers_logslice_env(tmp_path, monkeypatch):
    override = tmp_path / "override"
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(override))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache.default_cache_dir() == override


def test_default_cache_dir_uses_xdg_cache_home(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    assert cache.default_cache_dir() == tmp_path / "xdg" / "logslice"


def test_default_cache_dir_falls_back_to_home(tmp_path, monkeypatch):
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.delenv("XDG_CACHE_HOME", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path))
    assert cache.default_cache_dir() == tmp_path / ".cache" / "logslice"


def test_empty_env_vars_are_ignored(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", "")
    monkeypatch.setenv("HOME", str(tmp_path))
    assert cache.default_cache_dir() == tmp_path / ".cache" / "logslice"


def test_explicit_directory_wins_over_env(tmp_path, monkeypatch):
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "override"))
    log = make_log(tmp_path)
    explicit = tmp_path / "explicit"
    entry = cache.store(log, parse_file(log), directory=explicit)
    assert entry.parent == explicit
    assert cache.load(log, directory=explicit) is not None


def test_env_dir_used_when_no_directory_given(tmp_path, monkeypatch):
    override = tmp_path / "override"
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(override))
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log))
    assert entry.parent == override
    assert cache.load(log) == parse_file(log)
