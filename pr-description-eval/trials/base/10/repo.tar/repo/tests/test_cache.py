import json

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def age_entry(entry, seconds):
    """Rewrite a cache entry so its created_at is ``seconds`` in the past."""
    data = json.loads(entry.read_text())
    data["created_at"] -= seconds
    entry.write_text(json.dumps(data))
    return data


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_fresh_entry_is_a_hit(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    cache.store(log, records, directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_expired_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    age_entry(entry, 7200)  # two hours old
    # default ttl is 3600s, so this is now stale
    assert cache.load(log, directory=tmp_path / "cache") is None
    # but a large enough ttl still returns it
    assert cache.load(log, directory=tmp_path / "cache", ttl=7200 * 2) is not None


def test_entry_exactly_at_ttl_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    age_entry(entry, 3600)
    # strictly older than ttl is a miss
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None


def test_missing_created_at_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    del data["created_at"]
    entry.write_text(json.dumps(data))
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_default_dir_from_logslice_env(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    override = tmp_path / "override"
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(override))
    entry = cache.store(log, parse_file(log))
    assert entry.parent == override
    assert cache.load(log) == parse_file(log)


def test_default_dir_from_xdg_env(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    xdg = tmp_path / "xdg"
    monkeypatch.delenv("LOGSLICE_CACHE_DIR", raising=False)
    monkeypatch.setenv("XDG_CACHE_HOME", str(xdg))
    entry = cache.store(log, parse_file(log))
    # XDG_CACHE_HOME gets a logslice subdirectory appended
    assert entry.parent == xdg / "logslice"
    assert cache.load(log) == parse_file(log)


def test_logslice_env_wins_over_xdg(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    override = tmp_path / "override"
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(override))
    monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "xdg"))
    entry = cache.store(log, parse_file(log))
    assert entry.parent == override


def test_empty_env_vars_are_ignored(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", "")
    monkeypatch.setenv("XDG_CACHE_HOME", "")
    # both empty -> falls through to ~/.cache/logslice
    assert cache._default_cache_dir() == cache.Path.home() / ".cache" / "logslice"


def test_explicit_directory_wins_over_env(tmp_path, monkeypatch):
    log = make_log(tmp_path)
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "override"))
    explicit = tmp_path / "explicit"
    entry = cache.store(log, parse_file(log), directory=explicit)
    assert entry.parent == explicit
    assert cache.load(log, directory=explicit) == parse_file(log)
    # and the env-var location was not used
    assert not (tmp_path / "override").exists()
