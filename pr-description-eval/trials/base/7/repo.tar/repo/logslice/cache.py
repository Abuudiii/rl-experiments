"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.

The cache directory is resolved when needed, in this order:

1. ``$LOGSLICE_CACHE_DIR``, if set and non-empty (used as-is);
2. ``$XDG_CACHE_HOME/logslice``, if ``XDG_CACHE_HOME`` is set and non-empty;
3. ``~/.cache/logslice``.

An explicit ``directory=`` argument to :func:`load` / :func:`store` takes
precedence over all of these.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

DEFAULT_TTL = 3600
FORMAT_VERSION = 1


def cache_key(path: Path) -> str:
    """Return the cache key for ``path``.

    The key is a SHA-256 over the file's resolved path, size and mtime, so
    editing, appending to or moving the file yields a different key.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _resolve_directory(directory: str | Path | None) -> Path:
    """Resolve the cache directory, preferring an explicit argument."""
    if directory:
        return Path(directory)
    env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_dir:
        return Path(env_dir)
    xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache_home:
        return Path(xdg_cache_home) / "logslice"
    return Path.home() / ".cache" / "logslice"


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(
    path: str | Path,
    directory: str | Path | None = None,
    *,
    ttl: float = DEFAULT_TTL,
) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    An entry is a miss if it is absent, unreadable, has the wrong format
    version, or is older than ``ttl`` seconds (measured from its
    ``created_at`` timestamp).
    """
    entry = _entry_path(Path(path), _resolve_directory(directory))
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    created_at = data.get("created_at")
    if not isinstance(created_at, (int, float)) or time.time() - created_at > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(
    path: str | Path,
    records: list[Record],
    directory: str | Path | None = None,
) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = _resolve_directory(directory)
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
