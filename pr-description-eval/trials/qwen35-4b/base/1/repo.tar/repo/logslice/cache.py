"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1


def _get_cache_dir() -> Path:
    """Return the cache directory using XDG spec with fallback.

    Priority order:
    1. $LOGSLICE_CACHE_DIR, if set and non-empty, used as-is (no `logslice` subdirectory)
    2. $XDG_CACHE_HOME/logslice, if XDG_CACHE_HOME is set and non-empty
    3. ~/.cache/logslice
    """
    # Explicit directory argument (from load/store) takes precedence
    if _explicit_cache_dir is not None:
        return Path(_explicit_cache_dir)
    
    # Check LOGSLICE_CACHE_DIR
    env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_dir:
        return Path(env_dir)
    
    # Check XDG_CACHE_HOME
    xdg_cache = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache:
        return Path(xdg_cache) / "logslice"
    
    # Default to ~/.cache/logslice
    return Path.home() / ".cache" / "logslice"


# Module-level variable that can be overridden by caller
_explicit_cache_dir: Path | None = None


def cache_key(path: Path) -> str:
    """Compute a cache key for the given path.

    The key is based on the resolved path, file size, and modification time.
    This ensures that any change to the file invalidates the cache entry.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: float | None = None) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    Entries expire after ``ttl`` seconds (default 3600). If an entry's
    ``created_at`` is more than ``ttl`` seconds old, it is treated as a miss.

    The cache key changes whenever the file is modified, so a stale entry is
    simply never looked up again.
    """
    if directory is None:
        directory = _get_cache_dir()
    entry = _entry_path(Path(path), directory)
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    if ttl is not None and data.get("created_at") is not None:
        if time.time() - data["created_at"] > ttl:
            return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    if directory is None:
        directory = _get_cache_dir()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
