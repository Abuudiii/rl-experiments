"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

# Cache directory can be configured via LOGSLICE_CACHE_DIR environment variable
# Default: ~/.cache/logslice
_cache_dir_env = os.environ.get("LOGSLICE_CACHE_DIR")
CACHE_DIR = Path(_cache_dir_env) if _cache_dir_env else Path.home() / ".cache" / "logslice"
FORMAT_VERSION = 1
DEFAULT_TTL_SECONDS = 86400  # 24 hours


def _make_cache_key(path: Path) -> str:
    """Generate a cache key for the given path."""
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{_make_cache_key(path)}.json"


def _is_expired(entry: dict, directory: Path) -> bool:
    """Check if a cache entry has expired."""
    expires_at = entry.get("expires_at")
    if expires_at is None:
        return False
    return time.time() > expires_at


def load(path: str | Path, directory: str | Path | None = None) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    Entries expire after the configured TTL (default 24 hours).
    """
    directory = Path(directory) if directory else CACHE_DIR
    entry = _entry_path(Path(path), directory)
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    if _is_expired(data, directory):
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = Path(directory) if directory else CACHE_DIR
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "expires_at": time.time() + DEFAULT_TTL_SECONDS,
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
