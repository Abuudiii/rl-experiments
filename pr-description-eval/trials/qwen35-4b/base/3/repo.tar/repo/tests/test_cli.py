import json
import time

import pytest

from logslice import cache
from logslice.cli import main
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:01Z DEBUG [db] query took 3ms
2024-05-01T12:00:02Z WARN [http] slow response /search 1200ms
this line is not a log record
2024-05-01T13:15:00Z ERROR [db] connection reset by peer
2024-05-02T08:00:00Z INFO [auth] user alice logged in
"""


@pytest.fixture
def log_file(tmp_path):
    path = tmp_path / "app.log"
    path.write_text(SAMPLE)
    return path


def test_prints_matching_records(log_file, capsys):
    assert main([str(log_file), "--level", "error"]) == 0
    assert capsys.readouterr().out == "2024-05-01T13:15:00Z ERROR [db] connection reset by peer\n"


def test_json_output(log_file, capsys):
    main([str(log_file), "-c", "auth", "--json"])
    rows = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert rows == [
        {
            "timestamp": "2024-05-02T08:00:00Z",
            "level": "INFO",
            "component": "auth",
            "message": "user alice logged in",
            "line_no": 6,
        }
    ]


def test_count_by_component(log_file, capsys):
    main([str(log_file), "--count-by", "component"])
    assert capsys.readouterr().out == "db    2\nhttp  2\nauth  1\n"


def test_count_by_json(log_file, capsys):
    main([str(log_file), "--count-by", "level", "--json"])
    assert json.loads(capsys.readouterr().out) == {"INFO": 2, "DEBUG": 1, "ERROR": 1, "WARNING": 1}


def test_missing_file_exit_code(tmp_path, capsys):
    assert main([str(tmp_path / "nope.log")]) == 2
    assert "nope.log" in capsys.readouterr().err


def test_cache_flag_reuses_parsed_records(log_file, tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(cache, "get_cache_directory", lambda: tmp_path / "cache")
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    first = capsys.readouterr().out
    assert len(list((tmp_path / "cache").glob("*.json"))) == 1

    def fail(path):
        raise AssertionError("parse_file should not be called on a cache hit")

    monkeypatch.setattr("logslice.cli.parse_file", fail)
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    assert capsys.readouterr().out == first


def test_no_cache_without_flag(log_file, tmp_path, monkeypatch):
    monkeypatch.setattr(cache, "get_cache_directory", lambda: tmp_path / "cache")
    main([str(log_file)])
    assert not (tmp_path / "cache").exists()


def test_cache_ttl_option_expires_entries(log_file, tmp_path, monkeypatch):
    """Test that expired cache entries cause re-parsing."""
    monkeypatch.setattr(cache, "get_cache_directory", lambda: tmp_path / "cache")
    
    # First run - should cache
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    assert len(list((tmp_path / "cache").glob("*.json"))) == 1
    
    # Set cache entry to expired
    cache_entry = list((tmp_path / "cache").glob("*.json"))[0]
    data = json.loads(cache_entry.read_text())
    data["created_at"] = time.time() - 4000  # 4000 seconds ago
    cache_entry.write_text(json.dumps(data))
    
    # Second run - should miss and reparse
    call_count = [0]
    
    def count_calls(path):
        call_count[0] += 1
        return parse_file(path)
    
    # Patch parse_file to count calls
    original_parse_file = main.__globals__.get('parse_file', None)
    if original_parse_file:
        main.__globals__['parse_file'] = count_calls
    
    try:
        result = main([str(log_file), "--cache", "--count-by", "level"])
        assert result == 0
        assert call_count[0] == 1, "parse_file should have been called on cache miss"
    finally:
        # Restore original parse_file
        if original_parse_file:
            main.__globals__['parse_file'] = original_parse_file


def test_cache_ttl_custom_value(log_file, tmp_path, monkeypatch, capsys):
    """Test that custom --cache-ttl value is respected."""
    monkeypatch.setattr(cache, "get_cache_directory", lambda: tmp_path / "cache")
    
    # First run - should cache
    assert main([str(log_file), "--cache", "--cache-ttl", "100", "--count-by", "level"]) == 0
    
    # Set cache entry to expired (5000 seconds ago)
    cache_entry = list((tmp_path / "cache").glob("*.json"))[0]
    data = json.loads(cache_entry.read_text())
    data["created_at"] = time.time() - 5000  # 5000 seconds ago
    
    # Second run with custom TTL (100) - should miss because entry is expired
    assert main([str(log_file), "--cache", "--cache-ttl", "100", "--count-by", "level"]) == 0
