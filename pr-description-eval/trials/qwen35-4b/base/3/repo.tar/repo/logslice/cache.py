"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1


def get_cache_directory() -> Path:
    """Determine the cache directory following XDG spec with fallback.
    
    Returns the directory in this order:
    1. $LOGSLICE_CACHE_DIR if set and non-empty (used as-is, no subdirectory)
    2. $XDG_CACHE_HOME/logslice if XDG_CACHE_HOME is set and non-empty
    3. ~/.cache/logslice as fallback
    """
    # Check for explicit LOGSLICE_CACHE_DIR
    env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_dir:
        return Path(env_dir)
    
    # Check XDG_CACHE_HOME
    xdg_cache = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache:
        return Path(xdg_cache) / "logslice"
    
    # Fallback to default
    return Path.home() / ".cache" / "logslice"


def cache_key(path: Path) -> str:
    """Compute a cache key from file metadata.
    
    The key is based on the resolved path, file size, and modification time,
    so it changes when the file is edited or appended to.
    
    Args:
        path: The file path to cache.
    
    Returns:
        A SHA-256 hash of the file's metadata.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: int = 3600) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.
    
    Args:
        path: The log file path.
        directory: Optional cache directory (overrides environment defaults).
        ttl: Time-to-live in seconds. Entries older than this are treated as misses.
    
    Returns:
        The cached records, or ``None`` if not found or expired.
    """
    entry = _entry_path(Path(path), Path(directory) if directory else get_cache_directory())
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    # Check TTL
    created_at = data.get("created_at")
    if created_at is not None and time.time() - created_at > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location.
    
    Args:
        path: The log file path.
        records: The parsed records to cache.
        directory: Optional cache directory (overrides environment defaults).
    
    Returns:
        The path to the cache entry.
    """
    directory = Path(directory) if directory else get_cache_directory()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"
