"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

# Priority for cache directory selection:
# 1. $LOGSLICE_CACHE_DIR if set and non-empty
# 2. $XDG_CACHE_HOME/logslice if XDG_CACHE_HOME is set and non-empty
# 3. ~/.cache/logslice (fallback)
CACHE_DIR = Path.home() / ".cache" / "logslice"
FORMAT_VERSION = 1


def cache_key(path: Path) -> str:
    """Generate a cache key for a log file.

    The key is computed from the resolved path, size, and modification time,
    so editing or appending to a log automatically invalidates its entry.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def entry_path(path: Path, directory: Path) -> Path:
    """Return the cache entry path for ``path`` within ``directory``."""
    return directory / f"{cache_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: int = 3600) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.

    Entries expire after ``ttl`` seconds. The key changes whenever the file is
    modified, so a stale entry is simply never looked up again.
    """
    # Determine the cache directory based on priority
    if directory is not None:
        cache_dir = Path(directory)
    else:
        # Try $LOGSLICE_CACHE_DIR first
        env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
        if env_dir:
            cache_dir = Path(env_dir)
        else:
            # Try $XDG_CACHE_HOME/logslice
            xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
            if xdg_cache_home:
                cache_dir = Path(xdg_cache_home) / "logslice"
            else:
                cache_dir = CACHE_DIR

    entry = entry_path(Path(path), cache_dir)
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    # Check TTL
    if data.get("created_at") is not None:
        age = time.time() - data["created_at"]
        if age > ttl:
            return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    if directory is not None:
        cache_dir = Path(directory)
    else:
        # Try $LOGSLICE_CACHE_DIR first
        env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
        if env_dir:
            cache_dir = Path(env_dir)
        else:
            # Try $XDG_CACHE_HOME/logslice
            xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
            if xdg_cache_home:
                cache_dir = Path(xdg_cache_home) / "logslice"
            else:
                cache_dir = CACHE_DIR
    cache_dir.mkdir(parents=True, exist_ok=True)
    entry = entry_path(Path(path), cache_dir)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
