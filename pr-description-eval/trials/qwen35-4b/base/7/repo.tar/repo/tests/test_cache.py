import json

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_cache_ttl_expires_old_entries(tmp_path):
    """Test that cache entries expire after TTL."""
    log = make_log(tmp_path)
    records = parse_file(log)
    # Store with a short TTL of 1 second
    entry = cache.store(log, records, directory=tmp_path / "cache", ttl=1)
    # Verify it loads immediately
    assert cache.load(log, directory=tmp_path / "cache") == records
    
    # Wait longer than TTL
    import time
    time.sleep(1.1)
    
    # Should be a miss now (use explicit TTL to ensure it uses the stored TTL)
    assert cache.load(log, directory=tmp_path / "cache", ttl=1) is None


def test_cache_ttl_default_3600_seconds(tmp_path):
    """Test that default TTL is 3600 seconds."""
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["ttl"] == 3600
