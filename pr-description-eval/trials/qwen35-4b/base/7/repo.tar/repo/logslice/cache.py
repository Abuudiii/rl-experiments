"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

FORMAT_VERSION = 1
DEFAULT_TTL = 3600

# Default cache directory (can be overridden by tests or environment)
CACHE_DIR = Path.home() / ".cache" / "logslice"


def _get_cache_dir() -> Path:
    """Return the cache directory, following XDG and custom precedence.

    Returns:
        Path to the cache directory, in this order:
        1. $LOGSLICE_CACHE_DIR if set and non-empty (used as-is, no 'logslice' subdir)
        2. $XDG_CACHE_HOME/logslice if XDG_CACHE_HOME is set and non-empty
        3. ~/.cache/logslice as fallback
    """
    # 1. Check for LOGSLICE_CACHE_DIR
    if os.environ.get("LOGSLICE_CACHE_DIR", ""):
        return Path(os.environ["LOGSLICE_CACHE_DIR"])
    
    # 2. Check for XDG_CACHE_HOME/logslice
    xdg_cache = os.environ.get("XDG_CACHE_HOME", "")
    if xdg_cache:
        return Path(xdg_cache) / "logslice"
    
    # 3. Default to ~/.cache/logslice
    return CACHE_DIR


def cache_key(path: Path) -> str:
    """Compute a cache key for a path.
    
    The key is derived from the resolved path, file size, and mtime, so the
    cache entry is invalidated whenever the file is modified.
    
    Args:
        path: The log file path
        
    Returns:
        A SHA-256 hex digest of the file's metadata
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: int | None = None) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.
    
    Args:
        path: The log file path
        directory: Optional cache directory (overrides automatic detection)
        ttl: Time-to-live in seconds. If set, entries older than this are
             treated as a miss. If not set, uses the TTL from the cached entry
             (default 3600 seconds).
    
    Returns:
        Cached records if found and not expired, None otherwise
    """
    if directory is None:
        directory = _get_cache_dir()
    
    entry = _entry_path(Path(path), Path(directory))
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    
    # Determine TTL to use
    if ttl is not None:
        ttl_to_use = ttl
    else:
        ttl_to_use = data.get("ttl", DEFAULT_TTL)
    
    # Check TTL
    created_at = data.get("created_at")
    if created_at is not None and time.time() - created_at > ttl_to_use:
        return None
    
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None, ttl: int | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location.
    
    Args:
        path: The log file path
        records: The records to cache
        directory: Optional cache directory (overrides automatic detection)
        ttl: Time-to-live in seconds. Defaults to 3600 seconds.
    
    Returns:
        Path to the cache entry
    """
    if directory is None:
        directory = _get_cache_dir()
    
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "ttl": ttl if ttl is not None else DEFAULT_TTL,
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
