"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

# Backward compatibility constant
CACHE_DIR = Path.home() / ".cache" / "logslice"
FORMAT_VERSION = 1
DEFAULT_TTL = 3600  # Default cache TTL in seconds (1 hour)


def resolve_cache_dir(directory: str | Path | None = None) -> Path:
    """Resolve the cache directory using XDG spec with fallback.
    
    Returns the cache directory in this priority order:
    1. `directory` argument (if provided)
    2. $LOGSLICE_CACHE_DIR (if set and non-empty)
    3. $XDG_CACHE_HOME/logslice (if XDG_CACHE_HOME is set and non-empty)
    4. ~/.cache/logslice (default)
    """
    if directory is not None:
        return Path(directory)
    
    env_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_dir:
        return Path(env_dir)
    
    xdg_cache = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache:
        return Path(xdg_cache) / "logslice"
    
    return Path.home() / ".cache" / "logslice"


def cache_key(path: Path) -> str:
    """Generate a cache key for a log file.
    
    The key is computed from the file's resolved path, size, and mtime,
    so the cache entry is invalidated when the file is edited or appended to.
    
    Args:
        path: The log file path
        
    Returns:
        A SHA-256 hash of the file metadata
    """
    stat = path.stat()
    raw = f"{path.resolve()}\0{stat.st_size}\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: int | None = None) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.
    
    Args:
        path: The log file path
        directory: Optional cache directory (overrides environment defaults)
        ttl: Time-to-live in seconds. Entries older than this are treated as misses.
             Default is 3600 seconds (1 hour).
    
    Returns:
        The cached records or None on miss
    """
    directory = resolve_cache_dir(directory)
    entry = _entry_path(Path(path), directory)
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    
    # Check TTL if specified or not None (default is 3600)
    if ttl is not None:
        if "created_at" in data and data["created_at"] + ttl < time.time():
            return None
    elif "created_at" in data and data["created_at"] + DEFAULT_TTL < time.time():
        return None
    
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = resolve_cache_dir(directory)
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
