import json
import os
import time
from datetime import datetime, timedelta

import pytest

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_ttl_expires_old_entries(tmp_path, monkeypatch):
    """Test that cache entries expire after TTL seconds."""
    log = make_log(tmp_path)
    records = parse_file(log)
    # Store with explicit directory
    entry = cache.store(log, records, directory=tmp_path / "cache")
    
    # Get the created_at timestamp
    data = json.loads(entry.read_text())
    created_at = data["created_at"]
    
    # Modify the entry to have an old created_at (more than TTL seconds ago)
    old_created_at = created_at - 4000  # 4000 seconds ago, with default TTL of 3600
    entry.write_text(json.dumps({
        "version": cache.FORMAT_VERSION,
        "source": str(log.resolve()),
        "created_at": old_created_at,
        "records": data["records"],
    }))
    
    # Load should return None (cache miss) due to TTL
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None


def test_ttl_with_explicit_ttl(tmp_path, monkeypatch):
    """Test that custom TTL works correctly."""
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    
    # Get the created_at timestamp
    data = json.loads(entry.read_text())
    created_at = data["created_at"]
    
    # Modify the entry to have an old created_at (more than TTL seconds ago)
    old_created_at = created_at - 3700  # 3700 seconds ago
    entry.write_text(json.dumps({
        "version": cache.FORMAT_VERSION,
        "source": str(log.resolve()),
        "created_at": old_created_at,
        "records": data["records"],
    }))
    
    # With 300 second TTL, this should be a miss (3700 > 300)
    assert cache.load(log, directory=tmp_path / "cache", ttl=300) is None
    
    # With 4000 second TTL, this should be a hit (3700 < 4000)
    assert cache.load(log, directory=tmp_path / "cache", ttl=4000) == records


def test_default_ttl(tmp_path, monkeypatch):
    """Test that default TTL (3600) works."""
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    
    # Get the created_at timestamp
    data = json.loads(entry.read_text())
    created_at = data["created_at"]
    
    # Modify the entry to have an old created_at (more than 3600 seconds ago)
    old_created_at = created_at - 4000  # 4000 seconds ago
    entry.write_text(json.dumps({
        "version": cache.FORMAT_VERSION,
        "source": str(log.resolve()),
        "created_at": old_created_at,
        "records": data["records"],
    }))
    
    # Should be a miss with default TTL (3600)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_custom_cache_dir_from_env(tmp_path, monkeypatch):
    """Test that LOGSLICE_CACHE_DIR environment variable is used."""
    custom_dir = tmp_path / "custom_cache"
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(custom_dir))
    
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records)
    
    # Should use the custom directory
    assert entry.parent == custom_dir
    assert not (tmp_path / "cache").exists()


def test_xdg_cache_dir_from_env(tmp_path, monkeypatch):
    """Test that XDG_CACHE_HOME environment variable is used."""
    xdg_dir = tmp_path / "xdg_cache"
    monkeypatch.setenv("XDG_CACHE_HOME", str(xdg_dir))
    
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records)
    
    # Should use XDG_CACHE_HOME/logslice
    assert entry.parent == xdg_dir / "logslice"
    assert not (tmp_path / "cache").exists()


def test_explicit_dir_overrides_env(tmp_path, monkeypatch):
    """Test that explicit directory argument overrides environment variables."""
    custom_dir = tmp_path / "explicit_cache"
    monkeypatch.setenv("LOGSLICE_CACHE_DIR", str(tmp_path / "env_cache"))
    
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=custom_dir)
    
    # Should use the explicit directory
    assert entry.parent == custom_dir
