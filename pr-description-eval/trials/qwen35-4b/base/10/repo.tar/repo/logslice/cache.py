"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

CACHE_DIR = Path.home() / ".cache" / "logslice"
FORMAT_VERSION = 1


def _get_cache_directory() -> Path:
    """Determine the cache directory using XDG spec with priority:
    
    1. $LOGSLICE_CACHE_DIR, if set and non-empty, used as-is (no 'logslice' subdirectory appended);
    2. otherwise $XDG_CACHE_HOME/logslice, if XDG_CACHE_HOME is set and non-empty;
    3. otherwise ~/.cache/logslice.
    """
    if LOGSLICE_CACHE_DIR := os.environ.get("LOGSLICE_CACHE_DIR", ""):
        if LOGSLICE_CACHE_DIR:
            return Path(LOGSLICE_CACHE_DIR)
    
    if XDG_CACHE_HOME := os.environ.get("XDG_CACHE_HOME", ""):
        if XDG_CACHE_HOME:
            return Path(XDG_CACHE_HOME) / "logslice"
    
    return CACHE_DIR


def _key(path: Path) -> str:
    """Generate a cache key from the file's resolved path, size and mtime.
    
    The key changes whenever the file is modified, so editing or appending to a
    log automatically invalidates its entry.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: int = 3600) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.
    
    Entries expire after ``ttl`` seconds. On a miss, the CLI re-parses the file
    and overwrites the entry.
    """
    entry = _entry_path(Path(path), Path(directory) if directory else _get_cache_directory())
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    created_at = data.get("created_at", 0)
    if time.time() - created_at > ttl:
        return None
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location."""
    directory = Path(directory) if directory else _get_cache_directory()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
