import json
import time

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache._key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache._key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_ttl_expiry(tmp_path):
    """Cache entries expire after TTL seconds."""
    log = make_log(tmp_path)
    records = parse_file(log)
    
    # Store cache entry
    cache.store(log, records, directory=tmp_path / "cache")
    
    # Verify cache hit
    assert cache.load(log, directory=tmp_path / "cache") == records
    
    # Read the created_at value from the cache entry
    import os
    cache_entry = list((tmp_path / "cache").glob("*.json"))[0]
    data = json.loads(cache_entry.read_text())
    created_at = data["created_at"]
    
    # Manually modify the cache entry to have an old timestamp
    old_timestamp = created_at - 7200  # 2 hours ago
    new_data = dict(data)
    new_data["created_at"] = old_timestamp
    cache_entry.write_text(json.dumps(new_data))
    
    # Should be a miss now
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None
    
    # Restore the original timestamp
    cache_entry.write_text(json.dumps(data))


def test_ttl_with_custom_ttl(tmp_path):
    """Cache entries expire after custom TTL."""
    log = make_log(tmp_path)
    records = parse_file(log)
    
    # Store cache entry
    cache.store(log, records, directory=tmp_path / "cache")
    
    # Verify cache hit
    assert cache.load(log, directory=tmp_path / "cache") == records
    
    # Read the created_at value from the cache entry
    import os
    cache_entry = list((tmp_path / "cache").glob("*.json"))[0]
    data = json.loads(cache_entry.read_text())
    created_at = data["created_at"]
    
    # Manually modify the cache entry to have an old timestamp (beyond default TTL)
    old_timestamp = created_at - 7200  # 2 hours ago
    new_data = dict(data)
    new_data["created_at"] = old_timestamp
    cache_entry.write_text(json.dumps(new_data))
    
    # Should be a miss with default TTL
    assert cache.load(log, directory=tmp_path / "cache", ttl=3600) is None
    
    # But should be a hit with longer TTL (7200 seconds, which is exactly the difference)
    # Using 7201 to account for floating-point precision
    assert cache.load(log, directory=tmp_path / "cache", ttl=7201) == records
    
    # Restore the original timestamp
    cache_entry.write_text(json.dumps(data))
