"""On-disk cache of parsed log records.

Parsing is the slow part of logslice on large files, so ``--cache`` stores the
parsed records as JSON and reuses them on the next run over the same file.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

from .parser import Record

# Priority order for cache directory resolution:
# 1. $LOGSLICE_CACHE_DIR (if set and non-empty)
# 2. $XDG_CACHE_HOME/logslice (if XDG_CACHE_HOME is set and non-empty)
# 3. ~/.cache/logslice
def _get_cache_dir() -> Path:
    """Return the cache directory using priority order."""
    # Priority 1: $LOGSLICE_CACHE_DIR
    env_cache_dir = os.environ.get("LOGSLICE_CACHE_DIR")
    if env_cache_dir:
        return Path(env_cache_dir)
    
    # Priority 2: $XDG_CACHE_HOME/logslice
    xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache_home:
        return Path(xdg_cache_home) / "logslice"
    
    # Priority 3: ~/.cache/logslice
    return Path.home() / ".cache" / "logslice"


FORMAT_VERSION = 1


def cache_key(path: Path) -> str:
    """Generate a cache key for the given file.
    
    The key is computed from the file's resolved path, size, and mtime.
    This ensures that any modification (including appending) invalidates the cache.
    """
    stat = path.stat()
    raw = f"{path.resolve()}\\0{stat.st_size}\\0{stat.st_mtime_ns}"
    return hashlib.sha256(raw.encode()).hexdigest()


def _entry_path(path: Path, directory: Path) -> Path:
    return directory / f"{cache_key(path)}.json"


def load(path: str | Path, directory: str | Path | None = None, ttl: float | None = None) -> list[Record] | None:
    """Return the cached records for ``path``, or ``None`` on a cache miss.
    
    Args:
        path: The log file to cache.
        directory: Optional cache directory. If None, uses the default cache directory.
        ttl: Time-to-live for cached entries in seconds. If None or an entry is
             older than ttl, it's treated as a miss. Default is 3600 seconds.
    
    Entries with a TTL expire based on their ``created_at`` timestamp.
    Stale entries are simply never looked up again.
    """
    entry = _entry_path(Path(path), Path(directory) if directory else _get_cache_dir())
    try:
        data = json.loads(entry.read_text())
    except (OSError, ValueError):
        return None
    if data.get("version") != FORMAT_VERSION:
        return None
    
    # Check TTL if specified
    if ttl is not None and data.get("created_at"):
        if time.time() - data["created_at"] > ttl:
            return None
    
    return [Record.from_dict(item) for item in data["records"]]


def store(path: str | Path, records: list[Record], directory: str | Path | None = None, ttl: float | None = None) -> Path:
    """Write ``records`` to the cache entry for ``path`` and return its location.
    
    Args:
        path: The log file to cache.
        records: The parsed records to cache.
        directory: Optional cache directory. If None, uses the default cache directory.
        ttl: Time-to-live for the cache entry in seconds. Default is 3600 seconds.
    
    The entry is never written if it would expire immediately (ttl <= 0).
    """
    directory = Path(directory) if directory else _get_cache_dir()
    directory.mkdir(parents=True, exist_ok=True)
    entry = _entry_path(Path(path), directory)
    data = {
        "version": FORMAT_VERSION,
        "source": str(Path(path).resolve()),
        "created_at": time.time(),
        "records": [record.to_dict() for record in records],
    }
    tmp = entry.with_suffix(f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data))
    os.replace(tmp, entry)
    return entry
