import json
import time

import pytest

from logslice import cache
from logslice.cli import main

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:01Z DEBUG [db] query took 3ms
2024-05-01T12:00:02Z WARN [http] slow response /search 1200ms
this line is not a log record
2024-05-01T13:15:00Z ERROR [db] connection reset by peer
2024-05-02T08:00:00Z INFO [auth] user alice logged in
"""


@pytest.fixture
def log_file(tmp_path):
    path = tmp_path / "app.log"
    path.write_text(SAMPLE)
    return path


def test_prints_matching_records(log_file, capsys):
    assert main([str(log_file), "--level", "error"]) == 0
    assert capsys.readouterr().out == "2024-05-01T13:15:00Z ERROR [db] connection reset by peer\n"


def test_json_output(log_file, capsys):
    main([str(log_file), "-c", "auth", "--json"])
    rows = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert rows == [
        {
            "timestamp": "2024-05-02T08:00:00Z",
            "level": "INFO",
            "component": "auth",
            "message": "user alice logged in",
            "line_no": 6,
        }
    ]


def test_count_by_component(log_file, capsys):
    main([str(log_file), "--count-by", "component"])
    assert capsys.readouterr().out == "db    2\nhttp  2\nauth  1\n"


def test_count_by_json(log_file, capsys):
    main([str(log_file), "--count-by", "level", "--json"])
    assert json.loads(capsys.readouterr().out) == {"INFO": 2, "DEBUG": 1, "ERROR": 1, "WARNING": 1}


def test_missing_file_exit_code(tmp_path, capsys):
    assert main([str(tmp_path / "nope.log")]) == 2
    assert "nope.log" in capsys.readouterr().err


def test_cache_flag_reuses_parsed_records(log_file, tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(cache, "_get_cache_dir", lambda: tmp_path / "cache")
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    first = capsys.readouterr().out
    assert len(list((tmp_path / "cache").glob("*.json"))) == 1

    def fail(path):
        raise AssertionError("parse_file should not be called on a cache hit")

    monkeypatch.setattr("logslice.cli.parse_file", fail)
    assert main([str(log_file), "--cache", "--count-by", "level"]) == 0
    assert capsys.readouterr().out == first


def test_no_cache_without_flag(log_file, tmp_path, monkeypatch):
    monkeypatch.setattr(cache, "_get_cache_dir", lambda: tmp_path / "cache")
    main([str(log_file)])
    assert not (tmp_path / "cache").exists()


def test_cache_ttl_flag(log_file, tmp_path, monkeypatch, capsys):
    """Test that --cache-ttl flag works correctly."""
    monkeypatch.setattr(cache, "_get_cache_dir", lambda: tmp_path / "cache")
    
    # First run should parse and cache
    assert main([str(log_file), "--cache", "--cache-ttl", "1", "--count-by", "level"]) == 0
    first = capsys.readouterr().out
    assert len(list((tmp_path / "cache").glob("*.json"))) == 1
    
    # Second run should use cache
    def fail(path):
        raise AssertionError("parse_file should not be called on a cache hit")
    
    monkeypatch.setattr("logslice.cli.parse_file", fail)
    assert main([str(log_file), "--cache", "--cache-ttl", "1", "--count-by", "level"]) == 0
    assert capsys.readouterr().out == first


def test_cache_ttl_expired(log_file, tmp_path, monkeypatch, capsys):
    """Test that cache entries expire after TTL."""
    monkeypatch.setattr(cache, "_get_cache_dir", lambda: tmp_path / "cache")
    
    # First run should parse and cache
    assert main([str(log_file), "--cache", "--cache-ttl", "1", "--count-by", "level"]) == 0
    first = capsys.readouterr().out
    
    # Wait for TTL to expire
    time.sleep(1.1)
    
    # Second run should re-parse (cache miss) - parse_file should be called
    def should_not_be_called(path):
        raise AssertionError("parse_file should have been called on cache miss")
    
    monkeypatch.setattr("logslice.cli.parse_file", should_not_be_called)
    with pytest.raises(AssertionError):
        main([str(log_file), "--cache", "--cache-ttl", "1", "--count-by", "level"])
