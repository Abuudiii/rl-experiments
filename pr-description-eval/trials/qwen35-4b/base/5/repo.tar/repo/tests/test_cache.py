import json
import time

from logslice import cache
from logslice.parser import parse_file

SAMPLE = """\
2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:05Z ERROR [db] connection reset by peer
"""


def make_log(tmp_path, text=SAMPLE):
    path = tmp_path / "app.log"
    path.write_text(text)
    return path


def test_round_trip(tmp_path):
    log = make_log(tmp_path)
    records = parse_file(log)
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert entry.parent == tmp_path / "cache"
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_miss_on_empty_cache(tmp_path):
    log = make_log(tmp_path)
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_key_changes_when_file_changes(tmp_path):
    log = make_log(tmp_path)
    before = cache.cache_key(log)
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.cache_key(log) != before


def test_modified_file_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    cache.store(log, parse_file(log), directory=tmp_path / "cache")
    with open(log, "a") as handle:
        handle.write("2024-05-01T12:00:09Z INFO [http] GET /about 200\n")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_corrupt_entry_is_a_miss(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    entry.write_text("{not json")
    assert cache.load(log, directory=tmp_path / "cache") is None


def test_entry_records_metadata(tmp_path):
    log = make_log(tmp_path)
    entry = cache.store(log, parse_file(log), directory=tmp_path / "cache")
    data = json.loads(entry.read_text())
    assert data["version"] == cache.FORMAT_VERSION
    assert data["source"] == str(log.resolve())
    assert isinstance(data["created_at"], float)


def test_cache_expiry(tmp_path):
    """Test that cache entries expire after TTL."""
    log = make_log(tmp_path)
    records = parse_file(log)
    
    # Store with a short TTL (1 second)
    entry = cache.store(log, records, directory=tmp_path / "cache", ttl=1)
    assert cache.load(log, directory=tmp_path / "cache", ttl=1) == records
    
    # Wait for TTL to expire
    time.sleep(1.1)
    
    # Should be a miss now
    assert cache.load(log, directory=tmp_path / "cache", ttl=1) is None
    
    # Re-store should work
    entry = cache.store(log, records, directory=tmp_path / "cache", ttl=1)
    assert cache.load(log, directory=tmp_path / "cache", ttl=1) == records


def test_cache_expiry_default_ttl(tmp_path):
    """Test default TTL is 3600 seconds."""
    log = make_log(tmp_path)
    records = parse_file(log)
    
    # Store with default TTL
    entry = cache.store(log, records, directory=tmp_path / "cache")
    assert cache.load(log, directory=tmp_path / "cache") == records
    
    # Default TTL is 3600 seconds, so it shouldn't expire yet
    assert cache.load(log, directory=tmp_path / "cache") == records


def test_cache_expiry_no_ttl(tmp_path):
    """Test that entries don't expire when ttl is None."""
    log = make_log(tmp_path)
    records = parse_file(log)
    
    # Store with no TTL (None)
    entry = cache.store(log, records, directory=tmp_path / "cache", ttl=None)
    assert cache.load(log, directory=tmp_path / "cache", ttl=None) == records
    
    # Should still work even after long time
    time.sleep(0.1)
    assert cache.load(log, directory=tmp_path / "cache", ttl=None) == records
