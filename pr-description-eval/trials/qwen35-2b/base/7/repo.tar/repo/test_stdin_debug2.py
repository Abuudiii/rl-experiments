#!/usr/bin/env python3
"""Debug stdin with --cache flag."""

import argparse
from logslice.cli import build_parser, read_records

parser = build_parser()
args = parser.parse_args(["-", "--cache", "--count-by", "level"])
print(f"args.path: {args.path}")
print(f"args.cache: {args.cache}")

# Simulate the read_records function
if args.path == "-":
    if not args.cache:
        print("prints error message")
    return list(args)
print("No error message")
