#!/usr/bin/env python3
"""Test stdin with --cache flag."""

import os
import tempfile
from pathlib import Path

from logslice import cache
from logslice.cli import main

SAMPLE = """2024-05-01T12:00:00Z INFO [http] GET /index.html 200
2024-05-01T12:00:01Z DEBUG [db] query took 3ms
2024-05-01T12:00:02Z WARN [http] slow response /search 1200ms
this line is not a log record
2024-05-01T13:15:00Z ERROR [db] connection reset by peer
2024-05-02T08:00:00Z INFO [auth] user alice logged in"""

tmp_path = Path(tempfile.mkdtemp())
cache.CACHE_DIR = tmp_path / "cache"

# Test 1: Read from stdin with --cache
print("--- Test 1: Read from stdin with --cache ---")
result = main(["-", "--cache", "--count-by", "level"])
print(f"Exit code: {result}")
print(f"Cache dir exists: {cache.CACHE_DIR.exists()}")
if cache.CACHE_DIR.exists():
    print(f"Cache contents: {list(cache.CACHE_DIR.glob('*'))}")

# Test 2: Read from stdin without --cache (should be ignored)
print("\n--- Test 2: Read from stdin without --cache ---")
cache.CACHE_DIR = tmp_path / "cache"
result = main(["-", "level"])
print(f"Exit code: {result}")
print(f"Cache dir exists: {cache.CACHE_DIR.exists()}")

# Cleanup
import shutil
shutil.rmtree(tmp_path)
