#!/usr/bin/env python3
"""Debug stdin with --cache flag."""

import argparse
from logslice.cli import build_parser

parser = build_parser()
args = parser.parse_args(["-", "--cache", "--count-by", "level"])
print(f"args.path: {args.path}")
print(f"args.cache: {args.cache}")
print(f"args.path == '-': {args.path == '-'}")
