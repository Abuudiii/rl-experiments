import re

with open('logslice/cli.py', 'r') as f:
    content = f.read()

# Find and replace the problematic line
# The current code is:
#     if args.path == "-":
#         if args.cache:
#             print("logslice: --cache is ignored when reading from stdin", file=sys.stderr)
#         return list(parse_lines(sys.stdin))
#
# We need to change it to:
#     if args.path == "-":
#         if not args.cache:
#             print("logslice: --cache is ignored when reading from stdin", file=sys.stderr)
#         return list(parse_lines(sys.stdin))

pattern = r'if args\.path == "":\s+if args\.cache:\s+print\("logslice: --cache is ignored when reading from stdin", file=sys\.stderr\)\s+return list\(parse_lines\(sys\.stdin\)\)'

replacement = r'if args.path == "-":\n        if not args.cache:\n            print("logslice: --cache is ignored when reading from stdin", file=sys.stderr)\n        return list(parse_lines(sys.stdin))'

# Actually, let me use sed to make the change
with open('logslice/cli.py', 'w') as f:
    f.write(content)
    # Use sed to replace the problematic line
    sed_cmd = """s/if args\.cache:\n            print\(\"logslice: --cache is ignored when reading from stdin\", file=sys\.stderr\)/if not args.cache:\n            print(\"logslice: --cache is ignored when reading from stdin\", file=sys.stderr)/"""
    import subprocess
    subprocess.run(['sed', '-i', sed_cmd], check=True)

print("Fixed!")
