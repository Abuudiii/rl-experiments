#!/usr/bin/env python3
"""Test script to verify type hints are correctly formatted."""

import ast
import inspect
import sys

def check_type_hints(file_path):
    """Check if all type hints have proper -> alignment."""
    with open(file_path, 'r') as f:
        content = f.read()
    
    try:
        tree = ast.parse(content)
    except SyntaxError as e:
        print(f"Syntax error in {file_path}: {e}")
        return False
    
    issues = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            if node.returns:
                # Check if the return type annotation is properly aligned
                if node.returns.lineno != node.end_lineno:
                    issues.append(f"Return type annotation on line {node.returns.lineno} is not aligned")
    
    return len(issues) == 0

if __name__ == "__main__":
    files = [
        "/repo/logslice/parser.py",
        "/repo/logslice/aggregate.py",
        "/repo/logslice/cli.py",
    ]
    
    for file in files:
        result = check_type_hints(file)
        print(f"{file}: {'PASS' if result else 'FAIL'}")
        if not result:
            print(f"  Issues: {check_type_hints(file)}")
