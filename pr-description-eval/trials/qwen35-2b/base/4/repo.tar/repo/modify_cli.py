#!/usr/bin/env python3
with open('logslice/cli.py', 'r') as f:
    content = f.read()

# Remove the --cache argument line
content = content.replace(
    """    parser.add_argument(
        "--cache", action="store_true",
        help="reuse parsed records from the on-disk cache (~/.cache/logslice)",
    )""",
    ""
)

# Remove the line that prints when --cache is used with stdin
content = content.replace(
    """        if args.cache:
            print("logslice: --cache is ignored when reading from stdin", file=sys.stderr)""",
    ""
)

# Remove the line that checks args.cache
content = content.replace(
    """    if not args.cache:
        return parse_file(args.path)
    records = cache.load(args.path)
    if records is None:
        records = parse_file(args.path)
        cache.store(args.path, records)""",
    """    return parse_file(args.path)"""
)

with open('logslice/cli.py', 'w') as f:
    f.write(content)

print("cli.py updated")
