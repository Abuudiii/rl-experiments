"""Test script to verify changes needed for PR #12."""
import os
import re

# Check if --cache flag exists in cli.py
with open('logslice/cli.py', 'r') as f:
    cli_content = f.read()
    
if '--cache' in cli_content:
    print("FAIL: --cache flag still exists in cli.py")
else:
    print("PASS: --cache flag removed from cli.py")

# Check if cache.py exists
if os.path.exists('logslice/cache.py'):
    print("FAIL: cache.py still exists")
else:
    print("PASS: cache.py removed")

# Check if test_cache.py exists
if os.path.exists('tests/test_cache.py'):
    print("FAIL: test_cache.py still exists")
else:
    print("PASS: test_cache.py removed")

# Check README.md for caching section
with open('README.md', 'r') as f:
    readme_content = f.read()

if 'Caching' in readme_content or 'cache' in readme_content.lower():
    print("FAIL: README.md still contains caching section")
else:
    print("PASS: README.md caching section removed")
