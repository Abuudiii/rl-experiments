# logslice

Filter and summarise structured log files.

## Usage

```bash
logslice logfile [options]
```

Options:
- `logfile`: log file to read, or `-` for stdin
- `-l, --level`: only show records at this level or above
- `-c, --component`: only show records from this component (repeatable)
- `--since`: ISO timestamp (inclusive)
- `--until`: ISO timestamp (exclusive)
- `-g, --grep`: regex to search for in the message
- `--count-by`: print record counts grouped by FIELD
- `--cache`: reuse parsed records from the on-disk cache (~/.cache/logslice)
- `--json`: emit JSON lines instead of text
- `--version`: show version information

## Examples

```bash
# Show only ERROR level records
logslice app.log --level error

# Show only http component records
logslice app.log --component http

# Show only records from 2024-05-01 to 2024-05-01T14:00:00Z
logslice app.log --since "2024-05-01T12:00:00Z" --until "2024-05-01T14:00:00Z"

# Search for "error" in the message
logslice app.log --grep "error"

# Show count by component
logslice app.log --count-by component

# JSON output
logslice app.log --count-by level --json
```

## Caching

Parsing dominates the runtime on large files. Pass `--cache` to store the
parsed records on disk and reuse them on the next run over the same file:

```bash
logslice --cache huge.log --count-by level   # parses and caches
logslice --cache huge.log --level error      # served from the cache
```

Cached results are stored as JSON in `~/.cache/logslice`, one entry per log
file. The cache key includes the file's size and modification time, so editing
or appending to a log invalidates its entry. Entries never expire; delete the
directory to clear the cache.

## Development

```bash
pip install -e /repo
```
